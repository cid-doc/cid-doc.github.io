CID
---
Copyright (C) 2012-2025 Eduardo Moraes <<emoraes25@gmail.com>>  


LINKS
------
- [Homepage](https://c-i-d.sourceforge.io)
- [Documentation](https://cid-doc.github.io)
- [Donations](https://sourceforge.net/p/c-i-d/donate)


REQUIREMENTS
-------------
- acl (= any)
- attr (= any)
- awk (= any)
- bash (>= 4)
- cifs-utils (>= 6.4)
- CUPS (= any)
- {diff,find,core}utils (= any)
- grep (= any)
- gzip (= any)
- hostname (= any)
- iproute[2] (= any)
- Kerberos (>= 1.13)
- keyutils (= any)
- mount (= any)
- pam_mount (>= 2.14)
- passwd (= any)
- ping (= any)
- pkexec (= any)
- Samba (>= 4.3.11)
- sed (= any)
- sudo (= any)
- Systemd (= any)
- Winbind (>= 4.3.11)
- xhost (= any)
- zenity (>= 3.18.1)


INSTALLATION
-------------
- Ubuntu:  
	sudo add-apt-repository -y ppa:emoraes25/cid  
	sudo apt update && sudo apt -y install cid cid-gtk  

- Debian:  
	keys_dir='/etc/apt/keyrings' ; repos_dir="${keys_dir%/*}/sources.list.d"  
	[ -d "$keys_dir" ] || sudo mkdir -m0755 -p "$keys_dir"  
	wget -qO - https://cid-doc.github.io/keys/CID-GPG-KEY | sudo gpg --dearmor -o "${keys_dir}/cid-archive-keyring.pgp"
	sudo wget -qO "${repos_dir}/cid.sources" https://cid-doc.github.io/docs/cid.sources  
	sudo apt update && sudo apt -y install cid cid-gtk  

- Fedora:  
	sudo rpm --import https://cid-doc.github.io/keys/CID-GPG-KEY  
	sudo dnf config-manager addrepo --from-repofile=https://cid-doc.github.io/docs/cid.repo  
	sudo dnf -y install cid  

- OpenSUSE:  
	sudo rpm --import https://cid-doc.github.io/keys/CID-GPG-KEY  
	sudo zypper ar https://cid-doc.github.io/docs/cid.repo  
	sudo zypper in cid  

- Other distros:  
	ver='x.x.x' #current version  
	wget https://downloads.sf.net/c-i-d/cid-${ver}.tar.gz  
	tar -xzf cid-${ver}.tar.gz  
	cd cid-${ver}  
	sudo ./INSTALL.sh  

> Note: Run **sudo ./INSTALL.sh uninstall** to uninstall the 
program files from the same version of the package.
